document.getElementById("analyzeBtn").addEventListener("click", function () {
  const emailText = document.getElementById("emailInput").value;
  const resultDiv = document.getElementById("result");

  const redFlags = [];

  // Check for generic greetings
  const genericGreetings = ["Dear User", "Dear Customer", "Valued Customer"];
  genericGreetings.forEach((greeting) => {
    if (emailText.includes(greeting)) {
      redFlags.push("Generic Greeting: Uses non-personalized terms like 'Dear Customer'.");
    }
  });

  // Check for urgency phrases
  const urgencyPhrases = ["immediately", "24 hours", "urgent"];
  urgencyPhrases.forEach((phrase) => {
    if (emailText.toLowerCase().includes(phrase)) {
      redFlags.push("Urgency Trap: Email uses urgency to pressure the recipient.");
    }
  });

  // Check for suspicious links
  const linkRegex = /http[s]?:\/\/[^\s]+/g;
  const links = emailText.match(linkRegex);
  if (links) {
    links.forEach((link) => {
      if (!link.includes("trusted-domain.com")) {
        redFlags.push(`Suspicious Link: Found a potentially malicious link - ${link}`);
      }
    });
  }

  // Check for sender email patterns
  const senderRegex = /From:\s(.+@.+\..+)/i;
  const senderMatch = emailText.match(senderRegex);
  if (senderMatch && !senderMatch[1].includes("trusted-domain.com")) {
    redFlags.push(`Unverified Sender: Email from suspicious address - ${senderMatch[1]}`);
  }

  // Display results
  if (redFlags.length === 0) {
    resultDiv.innerHTML = "<p>No phishing red flags detected!</p>";
  } else {
    resultDiv.innerHTML = "<p>Potential Phishing Red Flags:</p><ul>" +
      redFlags.map(flag => `<li>${flag}</li>`).join("") +
      "</ul>";
  }
});